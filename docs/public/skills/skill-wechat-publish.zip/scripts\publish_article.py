# -*- coding: utf-8 -*-
"""
微信公众号文章发布脚本
功能：将 Markdown 文章发布到公众号草稿箱
"""
import requests
import json
import os
import sys
import argparse
from pathlib import Path

# 修复 Windows 控制台编码问题
sys.stdout.reconfigure(encoding='utf-8')

# 加载配置
def load_config():
    config_paths = [
        'config/config.json',
        'config/wechat-config.json',
        os.path.expanduser('~/.openclaw/workspace-operation/wechat-config.json')
    ]
    
    for path in config_paths:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    raise FileNotFoundError("未找到配置文件，请复制 config/config.example.json 为 config/config.json 并配置")

# 获取 Token
def get_token(config):
    appid = config['wechat_official_account']['appid']
    appsecret = config['wechat_official_account']['appsecret']
    
    resp = requests.get(
        f'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={appsecret}'
    )
    token_data = resp.json()
    
    if 'access_token' not in token_data:
        raise Exception(f"Token 获取失败：{token_data}")
    
    return token_data['access_token']

# 清理旧草稿
def clean_drafts(token, max_drafts=20):
    resp = requests.post(
        f'https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={token}',
        json={'offset': 0, 'count': max_drafts, 'no_content': 1}
    )
    drafts = resp.json()
    
    if 'item' in drafts:
        for item in drafts['item']:
            mid = item.get('media_id', '')
            if mid:
                requests.post(
                    f'https://api.weixin.qq.com/cgi-bin/draft/delete?access_token={token}',
                    json={'media_id': mid}
                )
    
    return len(drafts.get('item', []))

# 上传封面图
def upload_cover(token, cover_path):
    if not os.path.exists(cover_path):
        raise FileNotFoundError(f"封面图不存在：{cover_path}")
    
    mime = 'image/jpeg' if cover_path.endswith('.jpg') or cover_path.endswith('.jpeg') else 'image/png'
    
    resp = requests.post(
        f'https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={token}&type=thumb',
        files={'media': ('cover.jpg', open(cover_path, 'rb'), mime)}
    )
    
    result = resp.json()
    if 'media_id' not in result:
        raise Exception(f"封面图上传失败：{result}")
    
    return result['media_id']

# 上传正文配图
def upload_images(token, image_dir):
    if not os.path.exists(image_dir):
        return []
    
    image_files = []
    for f in sorted(os.listdir(image_dir)):
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp')):
            image_files.append(f)
    
    image_urls = []
    for img_file in image_files:
        img_path = os.path.join(image_dir, img_file)
        mime = 'image/png' if img_file.endswith('.png') else 'image/jpeg'
        
        resp = requests.post(
            f'https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token={token}',
            files={'media': (img_file, open(img_path, 'rb'), mime)}
        )
        
        url = resp.json().get('url', '')
        image_urls.append(url)
        status = '✅' if url else '❌'
        print(f'{status} 上传 {img_file}: {"成功" if url else "失败"}', flush=True)
    
    return image_urls

# 构建 HTML 排版
def build_html(content, image_urls=None):
    """
    简单的 HTML 排版，可根据需要扩展为使用模板
    """
    # 这里可以集成更复杂的模板系统
    # 目前返回基础 HTML，实际使用时建议集成 publish_restaurant_v2.py 中的精美模板
    html = f'''<section style="padding:15px;font-size:15px;color:#333;line-height:2;">
{content}
</section>'''
    
    return html

# 发布草稿
def publish_draft(token, title, content, thumb_media_id, author='', digest=''):
    payload = {
        "articles": [{
            "title": title,
            "author": author,
            "content": content,
            "thumb_media_id": thumb_media_id,
            "digest": digest,
            "need_open_comment": 1,
            "only_fans_can_comment": 0
        }]
    }
    
    json_str = json.dumps(payload, ensure_ascii=False)
    resp = requests.post(
        f'https://api.weixin.qq.com/cgi-bin/draft/add?access_token={token}',
        data=json_str.encode('utf-8'),
        headers={'Content-Type': 'application/json; charset=utf-8'}
    )
    
    result = resp.json()
    return result

# 主函数
def main():
    parser = argparse.ArgumentParser(description='微信公众号文章发布脚本')
    parser.add_argument('--article', required=True, help='Markdown 文章文件路径')
    parser.add_argument('--images', help='配图目录路径')
    parser.add_argument('--title', help='文章标题')
    parser.add_argument('--author', default='七点', help='作者名')
    parser.add_argument('--digest', help='文章摘要')
    parser.add_argument('--output', default='outputs', help='输出目录')
    parser.add_argument('--preview', action='store_true', help='仅预览，不发布')
    parser.add_argument('--verbose', action='store_true', help='详细输出')
    
    args = parser.parse_args()
    
    # 加载配置
    try:
        config = load_config()
    except FileNotFoundError as e:
        print(f'❌ 错误：{e}', file=sys.stderr)
        sys.exit(1)
    
    # 读取文章
    if not os.path.exists(args.article):
        print(f'❌ 文章文件不存在：{args.article}', file=sys.stderr)
        sys.exit(1)
    
    with open(args.article, 'r', encoding='utf-8') as f:
        article_content = f.read()
    
    # 提取标题（如果没有指定）
    title = args.title
    if not title:
        for line in article_content.split('\n'):
            if line.startswith('# '):
                title = line[2:].strip()
                break
        if not title:
            title = '未命名文章'
    
    # 提取摘要（如果没有指定）
    digest = args.digest
    if not digest:
        for line in article_content.split('\n'):
            if line.startswith('> '):
                digest = line[2:].strip()
                break
        if not digest:
            digest = article_content[:100].replace('\n', '') + '...'
    
    print('=' * 60)
    print('微信公众号文章发布')
    print('=' * 60)
    print(f'文章：{args.article}')
    print(f'标题：{title}')
    print(f'作者：{args.author}')
    print(f'摘要：{digest[:50]}...')
    print()
    
    if args.preview:
        print('📋 预览模式：不发布文章')
        return
    
    # 获取 Token
    try:
        token = get_token(config)
        print('1. ✅ Token OK', flush=True)
    except Exception as e:
        print(f'1. ❌ Token 获取失败：{e}', flush=True)
        sys.exit(1)
    
    # 清理旧草稿
    try:
        count = clean_drafts(token)
        print(f'2. ✅ 清理旧草稿完成（清理 {count} 篇）', flush=True)
    except Exception as e:
        print(f'2. ⚠️ 清理草稿失败：{e}', flush=True)
    
    # 上传封面图
    cover_path = None
    if args.images and os.path.exists(args.images):
        for f in ['cover.jpg', 'cover.png', '封面图.jpg']:
            if os.path.exists(os.path.join(args.images, f)):
                cover_path = os.path.join(args.images, f)
                break
    
    if not cover_path:
        # 使用默认封面
        default_cover = os.path.join(os.path.dirname(__file__), 'default_cover.jpg')
        if os.path.exists(default_cover):
            cover_path = default_cover
        else:
            print('3. ⚠️ 无封面图，使用默认封面', flush=True)
            cover_path = None
    
    thumb_media_id = ''
    if cover_path:
        try:
            thumb_media_id = upload_cover(token, cover_path)
            print(f'3. ✅ 封面图上传成功：{thumb_media_id[:30]}...', flush=True)
        except Exception as e:
            print(f'3. ❌ 封面图上传失败：{e}', flush=True)
            sys.exit(1)
    
    # 上传正文配图
    image_urls = []
    if args.images:
        print('4. 上传正文配图:')
        try:
            image_urls = upload_images(token, args.images)
            success_count = sum(1 for url in image_urls if url)
            print(f'✅ 上传成功：{success_count}/{len(image_urls)}', flush=True)
        except Exception as e:
            print(f'❌ 配图上传失败：{e}', flush=True)
    
    # 构建 HTML（这里简化处理，实际应该用模板）
    # 建议：集成 publish_restaurant_v2.py 中的精美 HTML 模板
    html_content = f'''<section style="padding:15px;font-size:15px;color:#333;line-height:2;">
{article_content.replace('\n', '<br/>')}
</section>'''
    
    # 发布草稿
    print('6. 发布草稿...')
    try:
        result = publish_draft(token, title, html_content, thumb_media_id, args.author, digest)
        
        if 'media_id' in result:
            print(f'\n6. ✅ PUBLISHED! media_id={result["media_id"]}', flush=True)
            print(f'\n🎉 文章发布成功！', flush=True)
            print(f'📱 请登录公众号后台预览草稿箱', flush=True)
        else:
            print(f'\n6. ❌ ERROR: {result}', flush=True)
            print(f'\n发布失败，请检查错误信息', flush=True)
    except Exception as e:
        print(f'\n6. ❌ 发布失败：{e}', flush=True)
        sys.exit(1)

if __name__ == '__main__':
    main()
