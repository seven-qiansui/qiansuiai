# -*- coding: utf-8 -*-
"""
AI 配图生成脚本
使用心宝 API (Gemini 2.5 Flash Image) 生成文章配图
"""
import requests
import json
import os
import sys
import base64
import time
import argparse

# 修复 Windows 控制台编码问题
sys.stdout.reconfigure(encoding='utf-8')

# 加载配置
def load_config():
    config_paths = [
        'config/config.json',
        os.path.expanduser('~/.openclaw/workspace-operation/wechat-config.json')
    ]
    
    for path in config_paths:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    raise FileNotFoundError("未找到配置文件")

# 生成单张图片
def generate_image(config, prompt, filename, output_dir):
    xinbao_config = config.get('xinbao_api', {})
    base_url = xinbao_config.get('base_url', 'https://xinbaoapi.dpdns.org')
    api_key = xinbao_config.get('api_key', '')
    model = xinbao_config.get('model', 'gemini-2.5-flash-image')
    aspect_ratio = xinbao_config.get('aspect_ratio', '16_9')
    
    if not api_key:
        raise Exception("未配置心宝 API Key")
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # 使用 Gemini 原生格式
    payload = {
        "contents": [{
            "parts": [{
                "text": prompt
            }]
        }],
        "generationConfig": {
            "responseModalities": ["IMAGE"],
            "imageGenerationConfig": {
                "numberOfImages": 1,
                "aspectRatio": aspect_ratio,
                "safetySetting": "BLOCK_NONE",
                "negativePrompt": "blurry, low quality, distorted, deformed, ugly"
            }
        }
    }
    
    try:
        response = requests.post(
            f"{base_url}/v1/models/{model}:generateContent",
            headers=headers,
            json=payload,
            timeout=xinbao_config.get('timeout', 120)
        )
        
        if response.status_code != 200:
            return False, f"请求失败：{response.text[:200]}"
        
        result = response.json()
        
        # 检查是否有图像生成
        if 'candidates' not in result:
            return False, f"无图像数据：{json.dumps(result, ensure_ascii=False)[:200]}"
        
        for candidate in result['candidates']:
            if 'content' in candidate and 'parts' in candidate['content']:
                for part in candidate['content']['parts']:
                    if 'inlineData' in part:
                        img_data = base64.b64decode(part['inlineData']['data'])
                        img_path = os.path.join(output_dir, filename)
                        
                        with open(img_path, 'wb') as f:
                            f.write(img_data)
                        
                        file_size = os.path.getsize(img_path)
                        return True, f"生成成功 ({file_size:,} bytes)"
        
        return False, "未找到图像数据"
    
    except Exception as e:
        return False, f"异常：{str(e)}"

# 主函数
def main():
    parser = argparse.ArgumentParser(description='AI 配图生成脚本')
    parser.add_argument('--prompts', required=True, help='提示词 JSON 文件路径')
    parser.add_argument('--output', default='outputs/images', help='输出目录')
    parser.add_argument('--batch', type=int, default=5, help='批量大小')
    parser.add_argument('--delay', type=int, default=2, help='请求间隔（秒）')
    parser.add_argument('--verbose', action='store_true', help='详细输出')
    
    args = parser.parse_args()
    
    # 加载配置
    try:
        config = load_config()
    except FileNotFoundError as e:
        print(f'❌ 错误：{e}', file=sys.stderr)
        sys.exit(1)
    
    # 加载提示词
    if not os.path.exists(args.prompts):
        print(f'❌ 提示词文件不存在：{args.prompts}', file=sys.stderr)
        sys.exit(1)
    
    with open(args.prompts, 'r', encoding='utf-8') as f:
        prompts = json.load(f)
    
    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)
    
    print('=' * 60)
    print('🎨 AI 配图生成')
    print('=' * 60)
    print(f'提示词文件：{args.prompts}')
    print(f'输出目录：{args.output}')
    print(f'图片数量：{len(prompts)}')
    print()
    
    success_count = 0
    failed_images = []
    
    for i, img_info in enumerate(prompts, 1):
        filename = img_info.get('filename', f'image_{i}.jpg')
        prompt_cn = img_info.get('prompt_cn', '')
        prompt_en = img_info.get('prompt_en', prompt_cn)
        description = img_info.get('description', '')
        
        # 优先使用英文 prompt（生成质量更高）
        prompt = prompt_en if prompt_en else prompt_cn
        
        print(f'\n{"="*60}')
        print(f'[{i}/{len(prompts)}] {description or filename}')
        print(f'文件：{filename}')
        print(f'Prompt: {prompt[:60]}...')
        print(f'{"="*60}')
        
        success, message = generate_image(config, prompt, filename, args.output)
        
        if success:
            print(f'✅ {message}', flush=True)
            success_count += 1
        else:
            print(f'❌ {message}', flush=True)
            failed_images.append(filename)
        
        # 避免请求过快
        if i < len(prompts):
            print(f'等待 {args.delay} 秒...')
            time.sleep(args.delay)
    
    # 总结
    print('\n' + '=' * 60)
    print('📊 生成结果总结')
    print('=' * 60)
    print(f'成功：{success_count}/{len(prompts)}')
    print(f'失败：{len(failed_images)}/{len(prompts)}')
    
    if failed_images:
        print(f'\n失败列表:')
        for f in failed_images:
            print(f'  - {f}')
    
    # 列出已生成的文件
    print('\n📁 已生成的文件:')
    for img_info in prompts:
        filename = img_info.get('filename', '')
        img_path = os.path.join(args.output, filename)
        if os.path.exists(img_path):
            file_size = os.path.getsize(img_path)
            print(f'  ✅ {filename} ({file_size:,} bytes / {file_size/1024/1024:.2f} MB)')
        else:
            print(f'  ❌ {filename} (未生成)')
    
    if success_count == len(prompts):
        print('\n🎉 所有配图生成成功！')
    else:
        print('\n⚠️ 部分配图生成失败')

if __name__ == '__main__':
    main()
