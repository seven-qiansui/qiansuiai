# 微信公众号发布技能包 - 使用指南

## 5 分钟快速上手

### 第 1 步：安装依赖

```bash
cd skill-wechat-publish
pip install requests pillow beautifulsoup4
```

### 第 2 步：配置公众号

复制配置模板并编辑：

```bash
cp config/wechat-config.example.json config/wechat-config.json
```

编辑 `config/wechat-config.json`：

```json
{
  "wechat_official_account": {
    "name": "七点同学的千岁日记",
    "appid": "wx255bf26278076943",
    "appsecret": "你的 appsecret",
    "type": "订阅号",
    "ip_whitelist": ["你的服务器 IP"]
  }
}
```

### 第 3 步：准备文章

创建 Markdown 格式的文章文件：

```markdown
# 文章标题

> 文章摘要

## 章节 1

内容...

## 章节 2

内容...
```

### 第 4 步：生成配图（可选）

创建配图提示词文件 `prompts.json`：

```json
[
  {
    "filename": "cover.jpg",
    "prompt": "穿龙虾服的狸花猫，在办公室里工作，日漫风格"
  },
  {
    "filename": "scene1.png",
    "prompt": "穿龙虾服的狸花猫，在使用电脑，日漫风格"
  }
]
```

生成配图：

```bash
python scripts/generate_images.py --prompts prompts.json --output outputs/images/
```

### 第 5 步：发布文章

```bash
python scripts/publish_article.py \
  --article article.md \
  --images outputs/images/ \
  --title "文章标题" \
  --author "作者名"
```

**输出**: media_id（草稿箱文章 ID）

---

## 详细使用指南

### 脚本 1: publish_article.py（主发布脚本）

**功能**: 将 Markdown 文章发布到公众号草稿箱

**参数**:
```bash
--article PATH        # Markdown 文章文件（必填）
--images DIR          # 配图目录（可选）
--title TEXT          # 文章标题（可选，从文章提取）
--author TEXT         # 作者名（可选）
--digest TEXT         # 摘要（可选，从文章提取）
--output PATH         # 输出目录（可选，默认 outputs/）
--preview             # 仅预览，不发布（可选）
--verbose             # 详细输出（可选）
```

**示例**:

```bash
# 基础发布
python scripts/publish_article.py --article article.md

# 指定配图和标题
python scripts/publish_article.py \
  --article article.md \
  --images outputs/images/ \
  --title "OpenClaw：普通人的 AI 超级助手" \
  --author "七点"

# 仅预览 HTML 效果
python scripts/publish_article.py --article article.md --preview
```

**输出**:
```
1. ✅ Token OK
2. ✅ 清理旧草稿完成
3. ✅ 封面图上传成功：RkF8KUFZZhUvkCEP8s57...
4. ✅ 上传 cover.jpg: 成功
4. ✅ 上传 scene1.png: 成功
...
6. ✅ PUBLISHED! media_id=RkF8KUFZZhUvkCEP8s57...
```

---

### 脚本 2: generate_images.py（AI 配图生成）

**功能**: 使用心宝 API 生成文章配图

**参数**:
```bash
--prompts PATH        # 提示词 JSON 文件（必填）
--output DIR          # 输出目录（可选，默认 outputs/images/）
--model TEXT          # 模型名称（可选，默认 gemini-2.5-flash-image）
--size TEXT           # 图片尺寸（可选，默认 1024x1024）
--ratio TEXT          # 宽高比（可选，默认 16_9）
--batch SIZE          # 批量大小（可选，默认 5）
--delay SECONDS       # 请求间隔（可选，默认 2 秒）
--verbose             # 详细输出（可选）
```

**提示词文件格式** (`prompts.json`):

```json
[
  {
    "filename": "cover.jpg",
    "prompt_cn": "穿龙虾服的狸花猫，在火锅店里当服务员",
    "prompt_en": "A cute tabby cat wearing a lobster costume, working in a hot pot restaurant",
    "description": "封面图：火锅店服务员"
  },
  {
    "filename": "scene1.png",
    "prompt_cn": "穿龙虾服的狸花猫，在接听电话",
    "prompt_en": "A cute tabby cat wearing a lobster costume, answering phone calls",
    "description": "场景 1：智能客服"
  }
]
```

**示例**:

```bash
# 基础生成
python scripts/generate_images.py --prompts prompts.json

# 指定输出目录和模型
python scripts/generate_images.py \
  --prompts prompts.json \
  --output outputs/images/ \
  --model gemini-2.5-flash-image

# 批量生成（每次 5 张，间隔 2 秒）
python scripts/generate_images.py --prompts prompts.json --batch 5 --delay 2
```

**输出**:
```
============================================================
🎨 生成 AI 配图
============================================================

[1/5] 封面图：火锅店服务员
文件：cover.jpg
Prompt: A cute tabby cat wearing a lobster costume...
状态码：200
✅ 生成成功！
   文件：cover.jpg
   大小：1,073,064 bytes (1.02 MB)
...
```

---

### 脚本 3: humanize_text.py（文本人性化）

**功能**: 检测并去除 AI 写作痕迹

**参数**:
```bash
ACTION              # 操作：detect/humanize/style/compare
--input PATH        # 输入文件（必填）
--output PATH       # 输出文件（可选）
--scene TEXT        # 场景：social/tech/formal（可选）
--style TEXT        # 风格：wechat/zhihu/xiaohongshu/casual（可选）
--verbose           # 详细输出（可选）
```

**示例**:

```bash
# 检测 AI 痕迹
python scripts/humanize_text.py detect --input article.md

# 人性化处理（社媒场景）
python scripts/humanize_text.py humanize \
  --input article.md \
  --scene social \
  --output article_clean.md

# 风格转换（微信公众号风）
python scripts/humanize_text.py style \
  --input article.md \
  --style wechat \
  --output article_wechat.md

# 前后对比
python scripts/humanize_text.py compare \
  --input article.md \
  --output comparison.md
```

---

## 完整工作流示例

### 示例：发布餐饮行业文章

```bash
# 1. 准备文章
cp examples/article_restaurant.md outputs/article.md

# 2. 检测 AI 痕迹（可选）
python scripts/humanize_text.py detect --input outputs/article.md

# 3. 人性化处理（可选）
python scripts/humanize_text.py humanize \
  --input outputs/article.md \
  --scene social \
  --output outputs/article_clean.md

# 4. 生成配图
python scripts/generate_images.py \
  --prompts examples/restaurant_prompts.json \
  --output outputs/images/

# 5. 发布文章
python scripts/publish_article.py \
  --article outputs/article_clean.md \
  --images outputs/images/ \
  --title "OpenClaw 杀进餐饮店：从后厨到前厅，让 AI 帮你多赚 30%" \
  --author "七点"

# 6. 查看输出
# 登录公众号后台 → 草稿箱 → 预览文章
```

---

## 配置详解

### 微信公众号配置 (`config/wechat-config.json`)

```json
{
  "wechat_official_account": {
    "name": "七点同学的千岁日记",
    "appid": "wx255bf26278076943",
    "appsecret": "378419603e1b5e4806239ec45556c1ef",
    "type": "订阅号",
    "ip_whitelist": ["113.91.188.84", "91.243.81.108"],
    "auto_clean_drafts": true,
    "max_drafts": 20
  }
}
```

| 参数 | 说明 | 默认值 |
|------|------|--------|
| name | 公众号名称 | - |
| appid | 公众号 AppID | - |
| appsecret | 公众号 AppSecret | - |
| type | 公众号类型 | 订阅号 |
| ip_whitelist | IP 白名单 | - |
| auto_clean_drafts | 自动清理旧草稿 | true |
| max_drafts | 保留草稿数量 | 20 |

### 心宝 API 配置 (`config/xinbao-config.json`)

```json
{
  "xinbao_api": {
    "base_url": "https://xinbaoapi.dpdns.org",
    "api_key": "sk-pOia1TpwMORPF0yg47At4shwtdRuOj3N40gWBBpzhu2UfiPn",
    "model": "gemini-2.5-flash-image",
    "size": "1024x1024",
    "aspect_ratio": "16_9",
    "safety_setting": "BLOCK_NONE",
    "negative_prompt": "blurry, low quality, distorted",
    "max_retries": 3,
    "timeout": 120
  }
}
```

| 参数 | 说明 | 默认值 |
|------|------|--------|
| base_url | API 地址 | https://xinbaoapi.dpdns.org |
| api_key | API Key | - |
| model | 图像生成模型 | gemini-2.5-flash-image |
| size | 图片尺寸 | 1024x1024 |
| aspect_ratio | 宽高比 | 16_9 |
| safety_setting | 安全设置 | BLOCK_NONE |
| negative_prompt | 负面提示词 | blurry, low quality |
| max_retries | 最大重试次数 | 3 |
| timeout | 超时时间（秒） | 120 |

---

## 故障排查

### 问题 1: IP 白名单报错

**错误**: `invalid ip xxx, not in whitelist`

**解决**:
1. 查看当前 IP：`curl ifconfig.me`
2. 登录公众号后台 → 设置 → 公众号设置 → 功能设置
3. IP 白名单 → 添加当前 IP
4. 保存后重试

### 问题 2: ACCESS_TOKEN 过期

**错误**: `access_token expired`

**解决**: 脚本会自动刷新，无需手动处理。如持续报错，检查 appid/appsecret 是否正确。

### 问题 3: 配图生成失败

**错误**: `Field "prompt" is required and must be a string`

**解决**:
1. 检查心宝 API Key 是否有效
2. 确认模型名称正确（gemini-2.5-flash-image）
3. 使用英文 prompt 重试

### 问题 4: 图片上传失败

**错误**: `invalid media_id`

**解决**:
1. 检查图片文件格式（jpg/png）
2. 确认图片大小不超过 2MB
3. 重新上传图片

---

## 最佳实践

### 1. 配图生成

- ✅ 使用英文 prompt（生成质量更高）
- ✅ 描述具体场景（人物、动作、环境）
- ✅ 指定风格（日漫、写实、水彩等）
- ✅ 添加质量词（high quality, detailed, professional）

**示例**:
```
A cute tabby cat wearing a lobster costume, 
working in a hot pot restaurant, serving steaming hot pot, 
anime style, Studio Ghibli quality, bright warm colors, 
detailed background, 16:9 aspect ratio
```

### 2. 文章排版

- ✅ 每个章节配 1 张图
- ✅ 图片之间至少间隔 1 段文字
- ✅ 使用卡片式布局区分内容
- ✅ 数据用表格展示更清晰

### 3. 发布流程

- ✅ 发布前预览 HTML 效果
- ✅ 检查所有图片是否正常显示
- ✅ 确认标题和摘要无误
- ✅ 先在草稿箱保存，确认后再发布

---

## 进阶技巧

### 技巧 1: 批量生成多套配图

```bash
# 为同一篇文章生成多套配图方案
python scripts/generate_images.py \
  --prompts prompts_v1.json \
  --output outputs/images/v1/

python scripts/generate_images.py \
  --prompts prompts_v2.json \
  --output outputs/images/v2/

# 选择最佳方案发布
python scripts/publish_article.py \
  --article article.md \
  --images outputs/images/v2/
```

### 技巧 2: 自定义 HTML 模板

编辑 `templates/article_template.html`，自定义：
- 头部/尾部样式
- 卡片颜色
- 字体大小
- 间距调整

### 技巧 3: 自动化发布

创建定时任务（如每天 12:00 发布）：

```bash
# Linux/Mac (crontab)
0 12 * * * cd /path/to/skill-wechat-publish && python scripts/publish_article.py --article today.md

# Windows (Task Scheduler)
# 创建定时任务，执行 publish_article.py
```

---

## 更新日志

### v1.0.0 (2026-03-21)
- ✅ 初始版本发布
- ✅ 支持 AI 配图生成
- ✅ 支持文本人性化处理
- ✅ 支持 HTML 精美排版
- ✅ 支持自动发布到草稿箱

---

**最后更新**: 2026-03-21  
**版本**: v1.0.0  
**维护**: 七点同学的千岁日记
