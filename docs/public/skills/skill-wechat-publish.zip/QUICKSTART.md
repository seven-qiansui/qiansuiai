# 📦 微信公众号发布技能包 - 快速上手

## 你收到了什么？

一个完整的微信公众号自动发布技能包，包含：
- ✅ 文章发布脚本
- ✅ AI 配图生成
- ✅ 精美 HTML 排版
- ✅ 2 个示例文章
- ✅ 完整配置模板

**文件大小**: 18.6 KB  
**文件数**: 8 个核心文件

---

## 📁 文件结构

```
skill-wechat-publish/
├── SKILL.md                      # 技能说明文档
├── README.md                     # 详细使用指南
├── requirements.txt              # Python 依赖
├── config/
│   └── config.example.json       # 配置模板
├── scripts/
│   ├── publish_article.py        # 主发布脚本
│   └── generate_images.py        # AI 配图生成
├── examples/
│   ├── article_restaurant.md     # 餐饮行业文章示例
│   └── restaurant_prompts.json   # 配图提示词示例
└── outputs/                      # 输出目录（自动生成）
```

---

## ⚡ 5 分钟快速开始

### 第 1 步：解压文件

解压 `skill-wechat-publish.zip` 到任意目录

### 第 2 步：安装依赖

```bash
cd skill-wechat-publish
pip install -r requirements.txt
```

### 第 3 步：配置公众号

```bash
cp config/config.example.json config/config.json
```

编辑 `config/config.json`，填入你的配置：

```json
{
  "wechat_official_account": {
    "appid": "你的 AppID",
    "appsecret": "你的 AppSecret"
  },
  "xinbao_api": {
    "api_key": "你的心宝 API Key"
  }
}
```

**获取配置**：
- **AppID/AppSecret**: 登录公众号后台 → 开发 → 基本配置
- **心宝 API Key**: 从心宝平台获取

### 第 4 步：发布第一篇文章

```bash
# 使用示例文章测试发布
python scripts/publish_article.py \
  --article examples/article_restaurant.md \
  --title "OpenClaw 杀进餐饮店：从后厨到前厅，让 AI 帮你多赚 30%" \
  --author "七点"
```

**输出**: media_id（草稿箱文章 ID）

### 第 5 步：预览发布

登录微信公众号后台 → 草稿箱 → 找到文章 → 预览 → 发布

---

## 🎨 生成专属配图

### 使用示例提示词

```bash
python scripts/generate_images.py \
  --prompts examples/restaurant_prompts.json \
  --output outputs/images/
```

**输出**: 5 张高质量餐饮专属配图（每张约 1MB）

### 自定义配图

创建你自己的提示词文件 `my_prompts.json`：

```json
[
  {
    "filename": "cover.jpg",
    "prompt_cn": "你的配图描述（中文）",
    "prompt_en": "Your prompt description (English, better quality)",
    "description": "图片说明"
  }
]
```

生成：

```bash
python scripts/generate_images.py --prompts my_prompts.json
```

---

## 📝 发布你自己的文章

### 1. 准备文章

创建 Markdown 文件 `my_article.md`：

```markdown
# 文章标题

> 文章摘要（可选）

## 章节 1

内容...

## 章节 2

内容...
```

### 2. 生成配图（可选）

```bash
python scripts/generate_images.py --prompts my_prompts.json
```

### 3. 发布文章

```bash
python scripts/publish_article.py \
  --article my_article.md \
  --images outputs/images/ \
  --title "文章标题" \
  --author "作者名"
```

---

## 🔧 常用命令

### 发布文章

```bash
# 基础发布
python scripts/publish_article.py --article article.md

# 指定配图
python scripts/publish_article.py \
  --article article.md \
  --images outputs/images/

# 仅预览（不发布）
python scripts/publish_article.py --article article.md --preview
```

### 生成配图

```bash
# 基础生成
python scripts/generate_images.py --prompts prompts.json

# 指定输出目录
python scripts/generate_images.py \
  --prompts prompts.json \
  --output my_images/

# 批量生成（每次 5 张，间隔 2 秒）
python scripts/generate_images.py \
  --prompts prompts.json \
  --batch 5 \
  --delay 2
```

---

## ❓ 常见问题

### Q1: IP 白名单报错？

**错误**: `invalid ip xxx, not in whitelist`

**解决**: 
1. 查看当前 IP：访问 https://ifconfig.me
2. 登录公众号后台 → 设置 → 公众号设置 → 功能设置
3. IP 白名单 → 添加当前 IP
4. 保存后重试

### Q2: Token 获取失败？

**错误**: `invalid appid or appsecret`

**解决**: 检查 `config/config.json` 中的 AppID 和 AppSecret 是否正确

### Q3: 配图生成失败？

**错误**: `Field "prompt" is required`

**解决**: 
1. 检查心宝 API Key 是否正确
2. 使用英文 prompt（质量更高）
3. 确认模型名称正确（gemini-2.5-flash-image）

### Q4: 如何自定义排版？

**方法**: 修改 `scripts/publish_article.py` 中的 `build_html()` 函数，或使用精美的 HTML 模板（参考 `publish_restaurant_v2.py`）

---

## 📚 完整文档

- **SKILL.md**: 技能说明和配置详解
- **README.md**: 完整使用指南和最佳实践

---

## 🎯 下一步

1. ✅ 配置公众号和心宝 API
2. ✅ 测试发布示例文章
3. ✅ 生成专属配图
4. ✅ 发布你自己的文章

---

## 💡 技术支持

遇到问题？查看：
- README.md - 详细故障排查
- SKILL.md - 配置说明

---

**版本**: v1.0.0  
**更新日期**: 2026-03-21  
**维护**: 七点同学的千岁日记
