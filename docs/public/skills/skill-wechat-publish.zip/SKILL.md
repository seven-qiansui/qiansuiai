# 微信公众号发布技能包

## 技能概述

完整的微信公众号文章发布工作流，包含：
- ✅ 文章创作与人性化处理
- ✅ AI 配图生成（心宝 API）
- ✅ HTML 精美排版
- ✅ 自动发布到草稿箱

## 文件清单

```
skill-wechat-publish/
├── SKILL.md                      # 技能说明文档
├── README.md                     # 使用指南
├── config/
│   └── wechat-config.example.json # 配置模板
├── scripts/
│   ├── publish_article.py        # 主发布脚本
│   ├── generate_images.py        # AI 配图生成脚本
│   └── humanize_text.py          # 文本人性化处理脚本
├── templates/
│   └── article_template.html     # 文章 HTML 模板
├── outputs/                      # 输出目录（自动生成）
└── examples/                     # 示例文件
    ├── article_openclaw.md       # OpenClaw 介绍文章
    └── article_restaurant.md     # 餐饮行业文章
```

## 快速开始

### 1. 配置微信公众号

编辑 `config/wechat-config.json`：

```json
{
  "wechat_official_account": {
    "name": "你的公众号名称",
    "appid": "wx255bf26278076943",
    "appsecret": "your_appsecret",
    "type": "订阅号",
    "ip_whitelist": ["113.91.188.84", "91.243.81.108"]
  }
}
```

### 2. 配置心宝 API（配图生成）

编辑 `config/xinbao-config.json`：

```json
{
  "xinbao_api": {
    "base_url": "https://xinbaoapi.dpdns.org",
    "api_key": "sk-xxxxxxxxxxxxxxxx",
    "model": "gemini-2.5-flash-image",
    "ip_character": "穿龙虾服的狸花猫"
  }
}
```

### 3. 发布文章

```bash
# 基础发布（使用现有配图）
python scripts/publish_article.py --article outputs/article.md

# 完整流程（生成配图 + 发布）
python scripts/publish_article.py --article outputs/article.md --generate-images

# 仅生成配图
python scripts/generate_images.py --prompts prompts.json
```

## 核心功能

### 1. AI 配图生成

使用 Gemini 2.5 Flash Image 模型生成专属配图：

```python
# 示例：生成餐饮行业配图
prompts = [
    "穿龙虾服的狸花猫，在火锅店里当服务员，端着热气腾腾的火锅，日漫风格",
    "穿龙虾服的狸花猫，在接听订餐电话，餐饮店前台，日漫风格",
    # ... 更多 prompt
]

# 调用 API 生成
python scripts/generate_images.py --prompts prompts.json
```

**输出**: 5-10 张高质量配图（每张约 1MB）

### 2. 文本人性化处理

去除 AI 写作痕迹，让文章更自然：

```bash
# 检测 AI 痕迹
python scripts/humanize_text.py detect --input article.md

# 人性化处理
python scripts/humanize_text.py humanize --input article.md --scene social

# 风格转换（微信公众号风）
python scripts/humanize_text.py style --input article.md --style wechat
```

### 3. HTML 精美排版

自动生成公众号精美排版：
- ✅ 渐变色头部/尾部
- ✅ 卡片式内容区块
- ✅ 数据表格美化
- ✅ 图片阴影效果
- ✅ 响应式布局

### 4. 自动发布

一键发布到公众号草稿箱：

```bash
python scripts/publish_article.py \
  --article outputs/article.md \
  --images outputs/images/ \
  --title "文章标题" \
  --author "作者名"
```

**输出**: media_id（草稿箱文章 ID）

## 配置说明

### 微信公众号配置

| 参数 | 说明 | 示例 |
|------|------|------|
| name | 公众号名称 | 七点同学的千岁日记 |
| appid | 公众号 AppID | wx255bf26278076943 |
| appsecret | 公众号 AppSecret | 378419603e1b5e4806239ec45556c1ef |
| ip_whitelist | IP 白名单 | ["113.91.188.84", "91.243.81.108"] |

**注意**: ACCESS_TOKEN 有效期 2 小时，脚本会自动刷新。

### 心宝 API 配置

| 参数 | 说明 | 示例 |
|------|------|------|
| base_url | API 地址 | https://xinbaoapi.dpdns.org |
| api_key | API Key | sk-pOia1TpwMORPF0yg47At4shwtdRuOj3N40gWBBpzhu2UfiPn |
| model | 图像生成模型 | gemini-2.5-flash-image |
| ip_character | IP 形象描述 | 穿龙虾服的狸花猫 |

## 完整工作流

```
1. 确定选题
   ↓
2. 创作文章（Markdown 格式）
   ↓
3. 检测 AI 痕迹（可选）
   ↓
4. 人性化处理（可选）
   ↓
5. 生成配图（5-10 张）
   ↓
6. HTML 排版（自动）
   ↓
7. 发布到草稿箱
   ↓
8. 公众号后台预览 → 发布
```

## 示例文章

### 示例 1: OpenClaw 介绍
- 文件：`examples/article_openclaw.md`
- 标题：OpenClaw：普通人的 AI 超级助手，让工作效率翻 10 倍
- 配图：5 张通用龙虾猫插画

### 示例 2: 餐饮行业
- 文件：`examples/article_restaurant.md`
- 标题：OpenClaw 杀进餐饮店：从后厨到前厅，让 AI 帮你多赚 30%
- 配图：5 张餐饮专属龙虾猫插画

## 常见问题

### Q1: IP 白名单报错怎么办？
A: 登录公众号后台 → 设置 → 公众号设置 → 功能设置 → IP 白名单，添加当前服务器 IP。

### Q2: ACCESS_TOKEN 过期怎么办？
A: 脚本会自动刷新，无需手动处理。

### Q3: 配图生成失败怎么办？
A: 检查心宝 API Key 是否有效，或更换提示词重试。

### Q4: 人性化处理后内容变味怎么办？
A: 调整 `--scene` 参数（social/tech/formal），或手动微调输出结果。

## 依赖安装

```bash
pip install requests pillow beautifulsoup4
```

## 技术栈

- **语言**: Python 3.8+
- **图像生成**: Gemini 2.5 Flash Image (心宝 API)
- **HTTP 请求**: requests
- **图像处理**: pillow
- **HTML 解析**: beautifulsoup4

## 更新日志

### v1.0.0 (2026-03-21)
- ✅ 初始版本发布
- ✅ 支持 AI 配图生成
- ✅ 支持文本人性化处理
- ✅ 支持 HTML 精美排版
- ✅ 支持自动发布到草稿箱
- ✅ 包含 2 个示例文章

## 许可证

MIT License

## 联系方式

- **公众号**: 七点同学的千岁日记
- **作者**: 七点
- **邮箱**: seven_qidian@easyclaw.link

---

**最后更新**: 2026-03-21  
**版本**: v1.0.0
